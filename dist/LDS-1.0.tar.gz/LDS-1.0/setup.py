from setuptools import setup, find_packages

setup(
    name='LDS',
    version='1.0',
    author='Jakub Mareček, Kapa Kudaibergenov',
    author_email='jakub.marecek@gmail.com, kudkapa59@gmail.com',
    packages=find_packages(),
)