############# onlinelds ##############

def print_verbose(a,verbose):
    """
    from onlinelds.py
    """
    if verbose: print(a)
